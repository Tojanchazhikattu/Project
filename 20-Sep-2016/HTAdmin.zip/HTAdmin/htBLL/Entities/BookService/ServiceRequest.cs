﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using htDAL;


namespace htBLL
{
    public class ServiceRequest : BusinessBase<ServiceRequest>
    {
        #region Instance Properties

        public int ServiceRequestId { get; set; }

        public int? DeviceTypeID { get; set; }

        public int? HandsetModelID { get; set; }

        public int? DeviceColourID { get; set; }

        public int? IMEINo { get; set; }

        public String PassCode { get; set; }

        public int? NetworkID { get; set; }

        public Boolean? Handset { get; set; }

        public Boolean? Simcard { get; set; }

        public Boolean? MemoryCard { get; set; }

        public Boolean? Battery { get; set; }

        public Boolean? BackCover { get; set; }

        public String OtherAccessories { get; set; }

        public int? SearchChannelId { get; set; }

        public int? RepairTypeId { get; set; }

        public int? CustomerInformationId { get; set; }

        public int? ServiceDetailsId { get; set; }

        public int? ServiceRequestTypeId { get; set; } 

        #endregion Instance Properties

        #region Data access logic

        #region Get()
        protected override DataRow Get(int ServiceRequestId)
        {
            SqlParameter[] parameters = 		{			new SqlParameter("@ServiceRequestId", System.Data.SqlDbType.Int)		};
            parameters[0].Value = ServiceRequestId;
            try
            {
                OpenDatabase();
                DataTable dataTable = DataBase.QueryDataTable("sp_GetServiceRequest", parameters);
                return (dataTable.Rows.Count > 0) ? dataTable.Rows[0] : null;
            }
            finally
            {
                CloseDatabase();
            }
        }

        #endregion Get()

        #region GetAll()
        protected override DataTable GetAll()
        {
            try
            {
                OpenDatabase();
                DataTable dataTable = DataBase.QueryDataTable("sp_GetServiceRequestList", null);
                return dataTable;
            }
            finally
            {
                CloseDatabase();
            }
        }

        #endregion GetAll()

        #region Update()
        protected override void Update()
        {
            SqlParameter[] parameters =             {             new SqlParameter("ServiceRequestId",System.Data.SqlDbType.Int),             new SqlParameter("DeviceTypeID",System.Data.SqlDbType.Int),             new SqlParameter("HandsetModelID",System.Data.SqlDbType.Int),             new SqlParameter("DeviceColourID",System.Data.SqlDbType.Int),             new SqlParameter("IMEINo",System.Data.SqlDbType.Int),             new SqlParameter("PassCode",System.Data.SqlDbType.VarChar,25),             new SqlParameter("NetworkID",System.Data.SqlDbType.Int),             new SqlParameter("Handset",System.Data.SqlDbType.Bit),             new SqlParameter("Simcard",System.Data.SqlDbType.Bit),             new SqlParameter("MemoryCard",System.Data.SqlDbType.Bit),             new SqlParameter("Battery",System.Data.SqlDbType.Bit),             new SqlParameter("BackCover",System.Data.SqlDbType.Bit),             new SqlParameter("OtherAccessories",System.Data.SqlDbType.VarChar,100),             new SqlParameter("SearchChannelId",System.Data.SqlDbType.Int),             new SqlParameter("RepairTypeId",System.Data.SqlDbType.Int),             new SqlParameter("CustomerInformationId",System.Data.SqlDbType.Int),             new SqlParameter("ServiceDetailsId",System.Data.SqlDbType.Int),              new SqlParameter("ServiceRequestTypeId",System.Data.SqlDbType.Int),            };

            parameters[0].Value = (object)ServiceRequestId ?? DBNull.Value;
            parameters[1].Value = (object)DeviceTypeID ?? DBNull.Value;
            parameters[2].Value = (object)HandsetModelID ?? DBNull.Value;
            parameters[3].Value = (object)DeviceColourID ?? DBNull.Value;
            parameters[4].Value = (object)IMEINo ?? DBNull.Value;
            parameters[5].Value = (object)PassCode ?? DBNull.Value;
            parameters[6].Value = (object)NetworkID ?? DBNull.Value;
            parameters[7].Value = (object)Handset ?? DBNull.Value;
            parameters[8].Value = (object)Simcard ?? DBNull.Value;
            parameters[9].Value = (object)MemoryCard ?? DBNull.Value;
            parameters[10].Value = (object)Battery ?? DBNull.Value;
            parameters[11].Value = (object)BackCover ?? DBNull.Value;
            parameters[12].Value = (object)OtherAccessories ?? DBNull.Value;
            parameters[13].Value = (object)SearchChannelId ?? DBNull.Value;
            parameters[14].Value = (object)RepairTypeId ?? DBNull.Value;
            parameters[15].Value = (object)CustomerInformationId ?? DBNull.Value;
            parameters[16].Value = (object)ServiceDetailsId ?? DBNull.Value;
            parameters[17].Value = (object)ServiceRequestTypeId ?? DBNull.Value;
            DataBase.RunNonQuery("sp_UpdateServiceRequest", parameters);

        }

        #endregion Update()

        #region Delete()
        protected override void Delete()
        {
            Delete(ServiceRequestId);
        }
        protected override void Delete(int ServiceRequestId)
        {
            SqlParameter[] parameters = 	        {		        new SqlParameter("@ServiceRequestId", System.Data.SqlDbType.Int)	        };
            parameters[0].Value = (object)ServiceRequestId ?? DBNull.Value;
            try
            {
                OpenDatabase();
                DataBase.RunNonQuery("sp_DeleteServiceRequest", parameters);
            }
            finally
            {
                CloseDatabase();
            }
        }

        #endregion Delete()

        #region Add()
        protected override int Add()
        {
            SqlParameter[] parameters =              {             new SqlParameter("DeviceTypeID",System.Data.SqlDbType.Int),             new SqlParameter("HandsetModelID",System.Data.SqlDbType.Int),             new SqlParameter("DeviceColourID",System.Data.SqlDbType.Int),             new SqlParameter("IMEINo",System.Data.SqlDbType.Int),             new SqlParameter("PassCode",System.Data.SqlDbType.VarChar,25),             new SqlParameter("NetworkID",System.Data.SqlDbType.Int),             new SqlParameter("Handset",System.Data.SqlDbType.Bit),             new SqlParameter("Simcard",System.Data.SqlDbType.Bit),             new SqlParameter("MemoryCard",System.Data.SqlDbType.Bit),             new SqlParameter("Battery",System.Data.SqlDbType.Bit),             new SqlParameter("BackCover",System.Data.SqlDbType.Bit),             new SqlParameter("OtherAccessories",System.Data.SqlDbType.VarChar,100),             new SqlParameter("SearchChannelId",System.Data.SqlDbType.Int),             new SqlParameter("RepairTypeId",System.Data.SqlDbType.Int),             new SqlParameter("CustomerInformationId",System.Data.SqlDbType.Int),             new SqlParameter("ServiceDetailsId",System.Data.SqlDbType.Int),              new SqlParameter("ServiceRequestTypeId",System.Data.SqlDbType.Int),            };

            parameters[0].Value = (object)DeviceTypeID ?? DBNull.Value;
            parameters[1].Value = (object)HandsetModelID ?? DBNull.Value;
            parameters[2].Value = (object)DeviceColourID ?? DBNull.Value;
            parameters[3].Value = (object)IMEINo ?? DBNull.Value;
            parameters[4].Value = (object)PassCode ?? DBNull.Value;
            parameters[5].Value = (object)NetworkID ?? DBNull.Value;
            parameters[6].Value = (object)Handset ?? DBNull.Value;
            parameters[7].Value = (object)Simcard ?? DBNull.Value;
            parameters[8].Value = (object)MemoryCard ?? DBNull.Value;
            parameters[9].Value = (object)Battery ?? DBNull.Value;
            parameters[10].Value = (object)BackCover ?? DBNull.Value;
            parameters[11].Value = (object)OtherAccessories ?? DBNull.Value;
            parameters[12].Value = (object)SearchChannelId ?? DBNull.Value;
            parameters[13].Value = (object)RepairTypeId ?? DBNull.Value;
            parameters[14].Value = (object)CustomerInformationId ?? DBNull.Value;
            
            parameters[15].Value = (object)ServiceDetailsId ?? DBNull.Value;

            parameters[16].Value = (object)ServiceRequestTypeId ?? DBNull.Value;

            try
            {
                OpenDatabase();
                object returnObj = DataBase.QuerySingleValue("sp_AddServiceRequest", parameters);
                int newServiceRequestId;
                if (Int32.TryParse(returnObj.ToString(), out newServiceRequestId))
                {

                    return newServiceRequestId;

                }

                return 0;

            }

            finally
            {
                CloseDatabase();

            }

        }

        #endregion Add()

        #endregion Data access logic

        #region Methods

        protected override void AddBusinessRules()
        {
            //CustomerInformationId 
            //    ServiceDetailsId
            ValidationRuleList.AddRule((new RuleMethods()).IsRequired, new RuleCriteria("CustomerInformationId", "CustomerInformationId is required."));
            ValidationRuleList.AddRule((new RuleMethods()).IsRequired, new RuleCriteria("ServiceDetailsId", "ServiceDetailsId is required."));

        }

        public override void Map(DataRow dataRow)
        {
            if (dataRow != null)
            {

                if (!dataRow.IsNull("ServiceRequestId")) ServiceRequestId = Convert.ToInt32(dataRow["ServiceRequestId"]);
            }

        }

        public void SetPropertySet(string prop)
        {
            PropertySet(prop);

        }

        #endregion Methods
    }

}
