﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HTAdmin.Models;
using htBLL;

namespace HTAdmin.Controllers.Book
{
    public class BookSmartDeviceController : Controller
    {
        //
        // GET: /BookSmartDevice/
       // public IEnumerable<SelectListItem> selectList;

        public ActionResult Step1()
        {
            return View();
        }
        public ActionResult EquipmentInformation()
        {
            return View("EquipmentInformation", GetEquipmentInformation());
        }
        public ActionResult CustomerInformation()
        {
            return View("CustomerInformation", GetCustomerInformation());
        }
         public ActionResult RepairQuotes()
         {
             return View("RepairQuotes", GetRepairQuotes());
         }

         public ActionResult RequestSaved()
         {
             return View();
         }
        private DeviceDetails GetDeviceDetails()
        {
            if (Session["DeviceDetails"] == null)
            {
                Session["DeviceDetails"] = new DeviceDetails();
            }
            return (DeviceDetails)Session["DeviceDetails"];
        }

        private EquipmentInformation GetEquipmentInformation()
        {
            if (Session["EquipmentInformation"] == null)
            {
                Session["EquipmentInformation"] = new EquipmentInformation();
            }
            return (EquipmentInformation)Session["EquipmentInformation"];
        }

        private CustomerInformation GetCustomerInformation()
        {
            if (Session["CustomerInformation"] == null)
            {
                Session["CustomerInformation"] = new CustomerInformation();
            }
            return (CustomerInformation)Session["CustomerInformation"];
        }
        private RepairQuotes GetRepairQuotes()
        {
            if (Session["RepairQuotes"] == null)
            {
                RepairQuotes objRepairQuotes= new RepairQuotes();
                Session["RepairQuotes"] = objRepairQuotes;
            }
            return (RepairQuotes)Session["RepairQuotes"];
        }
        


        private void RemoveCustomer()
        {
            Session.Remove("DeviceDetails");
        }

        public JsonResult GetDeviceTypes()
        {
            BookSmartDeviceService bookSmartDeviceService = new BookSmartDeviceService();
            var resultData = bookSmartDeviceService.GetAllDeviceType().Select(c => new { Value = c.DeviceTypeId, Text = c.Name }).ToList();
            return Json(new { result = resultData }, JsonRequestBehavior.AllowGet);
            //list.Where(w => w.Name == "height").ToList().ForEach(s => s.Value = 30);
        }

        public JsonResult GetHandSetModel(int deviceTypeId)
        {
            BookSmartDeviceService bookSmartDeviceService = new BookSmartDeviceService();
            var resultHandSetModels = bookSmartDeviceService.GetHandSetModelForDeviceType(deviceTypeId).Select(c => new { Value = c.HandsetModelId, Text = c.Name })
                .ToList();
            return Json(new { result = resultHandSetModels }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetColours()
        {
            BookSmartDeviceService bookSmartDeviceService = new BookSmartDeviceService();
            var resultColours = bookSmartDeviceService.GetColours().Select(c => new { Value = c.ColourId, Text = c.colour }).ToList();
            return Json(new { result = resultColours }, JsonRequestBehavior.AllowGet);
        }


        public JsonResult GetNetworks()
        {
            BookSmartDeviceService bookSmartDeviceService = new BookSmartDeviceService();
            var resultColours = bookSmartDeviceService.GetNetworks().Select(c => new { Value = c.NetworkId, Text = c.name }).ToList();
            return Json(new { result = resultColours }, JsonRequestBehavior.AllowGet);
        }


        public ActionResult SubmitDeviceDetails(string submit, FormCollection fc)
        {

            if (submit == "Next")
            {
                if (ModelState.IsValid)
                {
                    DeviceDetails obj = GetDeviceDetails();
                    obj.DeviceTypeID = int.Parse(fc["ddlDeviceType"]);
                    obj.HandsetModelID = int.Parse(fc["ddlHandSetModel"]);
                    obj.DeviceColourID = int.Parse(fc["ddlColour"]);
                    obj.IMEINo = int.Parse(fc["imei-number"]);
                    obj.PassCode = fc["pass-code"].ToString();
                    obj.NetworkID = int.Parse(fc["ddlNetwork"]);

                    return RedirectToAction("EquipmentInformation");
                    //SubmitDeviceDetails
                    //return View("EquipmentInformation");
                }
            }
            return View();
        }
        public ActionResult SubmitEquipmentInformation(string submit, EquipmentInformation equipInfo)
        {
            if (submit == "Next")
            {
                if (ModelState.IsValid)
                {
                    EquipmentInformation obj = GetEquipmentInformation();
                    obj.Handset = equipInfo.Handset;
                    obj.Simcard = equipInfo.Simcard;
                    obj.MemoryCard = equipInfo.MemoryCard;
                    obj.Battery = equipInfo.Battery;
                    obj.BackCover = equipInfo.BackCover;
                    obj.OtherAccessories = equipInfo.OtherAccessories;

                    return RedirectToAction("CustomerInformation");
                }
            }
            return View();
        }
        public ActionResult SubmitCustomerInformation(string submit, CustomerInformation custInfo)
        {
            if (submit == "Next")
            {
                if (ModelState.IsValid)
                {
                    CustomerInformation obj = GetCustomerInformation();
                    obj.SearchChannelId = custInfo.SearchChannelId;
                    obj.FirstName = custInfo.FirstName;
                    obj.LastName = custInfo.LastName;
                    obj.ContactNo = custInfo.ContactNo;
                    obj.Email = custInfo.Email;
                    obj.Address = custInfo.Address;
                    obj.PostCode = custInfo.PostCode;

                    return RedirectToAction("RepairQuotes");
                }
            }
            return View();
        }
        
        [HttpGet]
    public ActionResult GetRepairTypeView(int selectedValue) // could use an enum for the selectable values
    {
        var model = GetRepairQuotes();
        string partialViewName = string.Empty;
        RepairType  selectedRepairType= model.lstRepairType.Where(s => s.RepairTypeId == selectedValue).FirstOrDefault();
        if (selectedRepairType!= null)
        {
            switch (selectedRepairType.Name)
            {
                case "Repair":
                    DeviceDetails deviceDetails = GetDeviceDetails();                    
                    model.initializeRepair(deviceDetails.DeviceTypeID);
                    partialViewName = "RepairView";
                    break;
                case "UnLocking":
                    partialViewName = "UnLockingView";
                    break;

                default:
                    throw new ArgumentException("unknown selected value", "selectedValue");
                    break;
            }
        }

        return PartialView(partialViewName, model);
    }


    [HttpPost, ActionName("SubmitRepairQuotes")]
    public ActionResult SubmitRepairQuotes(string submit, RepairQuotes repairQuotes)
    {
        if (submit == "Finish")
            {
                if (ModelState.IsValid)
                {
                    RepairQuotes objRepairQuotes = GetRepairQuotes();
                    objRepairQuotes.RepairTypeId = repairQuotes.RepairTypeId;
                    objRepairQuotes.serviceDetails.OtherRepair = repairQuotes.serviceDetails.OtherRepair;
                    objRepairQuotes.serviceDetails.OtherRepairCost = repairQuotes.serviceDetails.OtherRepairCost;
                    objRepairQuotes.serviceDetails.CollectionDateTime = repairQuotes.serviceDetails.CollectionDateTime;
                    objRepairQuotes.serviceDetails.MessageToEngineer = repairQuotes.serviceDetails.MessageToEngineer;
                    objRepairQuotes.serviceDetails.EngineerUserId = repairQuotes.serviceDetails.EngineerUserId;
                    objRepairQuotes.lstSelectedRepairs = repairQuotes.lstSelectedRepairs;

                    objRepairQuotes.serviceDetails.UnlockingCost = repairQuotes.serviceDetails.UnlockingCost;
                    objRepairQuotes.serviceDetails.AdancePayment = repairQuotes.serviceDetails.AdancePayment;
                    objRepairQuotes.serviceDetails.AdancePaymentAmount = repairQuotes.serviceDetails.AdancePaymentAmount;

                    BookSmartDeviceService bookSmartDeviceService = new BookSmartDeviceService();
                    bookSmartDeviceService.SaveSmartDeviceRequest(objRepairQuotes.serviceDetails,
                                                                    GetCustomerInformation(), 
                                                                    GetDeviceDetails(),
                                                                    GetEquipmentInformation(), 
                                                                    repairQuotes.RepairTypeId, 
                                                                    objRepairQuotes.lstSelectedRepairs);

                    return RedirectToAction("RequestSaved");
                }
            }
        return View();

    }
        
    }
}
