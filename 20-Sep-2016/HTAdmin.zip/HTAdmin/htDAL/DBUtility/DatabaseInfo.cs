﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Configuration;


namespace htDAL.DBUtility
{
    //public class DatabaseInfo
    //{
    //    public readonly ConnectionStringInfo ConnectionStrings;

    //    private DatabaseInfo() { }

        

    //    internal DatabaseInfo(XmlNode data)
    //    {
    //        ConnectionStrings = new ConnectionStringInfo();
    //        ConnectionStrings.htSolution = data.SelectSingleNode("/configuration/database/connectionStrings/connection[@key='Talon']").Attributes["value"].Value;
           
    //    }

    //    public class ConnectionStringInfo
    //    {
    //        public string htSolution;
    //    }
    //}
}
